
// const formctrl = document.querySelector('.from-control')

// let object = [
//   {
//   label:'Username',
//   id: "username",
//   placeholder: 'enter your name',
//     icon1:"fas fa-check-circle",
//     icon2:"fas fa-exclamation-circle",
//     error: "Eroor Msg"
// },
//   {
//   label:'Email',
//   id: 'email',
//   placeholder: 'enter your email',
//      icon1:"fas fa-check-circle",
//     icon2:"fas fa-exclamation-circle",
//     error: "Eroor Msg"
// },
//   {
//   label:'Phone Number',
//   id: "phone",
//   placeholder: 'enter your phone',
//     icon1:"fas fa-check-circle",
//     icon2:"fas fa-exclamation-circle",
//     error: "Eroor Msg"
// },
//   {
//   label:'Password',
//   id: "password",
//   placeholder: 'enter your password',
//     icon1:"fas fa-check-circle",
//     icon2:"fas fa-exclamation-circle",
//     error: "Eroor Msg"
// },
//   {
//   label:'Confirm Password',
//   id: "cpassword",
//   placeholder: 'Renter your password',
//     icon1:"fas fa-check-circle",
//     icon2:"fas fa-exclamation-circle",
//     error: "Eroor Msg"
// },
//   ]


// let data = ()=>{
//   return (formctrl.innerHTML = object.map((x)=>{
//     let{label,id,placeholder,icon1,icon2,error} = x
//     return `<label>${label}</label>
//         <input type="text" name="" id="${id}" placeholder="${placeholder}" autocomplete="off">
//         <i class="${icon1} "></i>
//         <i class="${icon2}"></i>
//         <small>${error}</small>
//     `
//   }).join(''))
// }
// data()


const form = document.getElementById('form')
const username = document.getElementById('username')
const email = document.getElementById('email')
const phone = document.getElementById('phone')
const password = document.getElementById('password')
const cpassword = document.getElementById('cpassword')


form.addEventListener('submit', (event) => {
  event.preventDefault();
  validate();
})

//more email validation



// ((((((((((define the validate function))))))))))

const validate = () => {
  const isEmail = () => {


    var atSymbol = emailVal.indexOf('@')
    if (atSymbol < 1) return false;
    var dot = emailVal.lastIndexOf('.')
    if (dot <= atSymbol + 2) return false;
    if (dot === emailVal.length - 1) return false;
    return true;

  }

  const userNameval = username.value.trim();
  const emailVal = email.value.trim();
  const phoneVal = phone.value.trim();
  const passwordVal = password.value.trim();
  const cpasswordVal = cpassword.value.trim();

  //validate your username

  if (userNameval === '') {
    setErrorMsg(username, 'username cannot be blank')
  } else if (userNameval.length <= 2) {
    setErrorMsg(username, 'username shoult be min 3 character')
  } else {
    setSuccessMsg(username)
  }
  //validate your email id

  if (emailVal === '') {
    setErrorMsg(email, 'email cannot be blank')
  } else if (!isEmail(emailVal)) {
    setErrorMsg(email, 'please enter valid email')
  } else {
    setSuccessMsg(email)
  }

  //(((((((({{{{{{{ //validate phone number}}}}}}}))))))))

  if (phoneVal === '') {
    setErrorMsg(phone, 'phone cannot be blank')
  } else if (phoneVal.length != 10) {
    setErrorMsg(phone, 'Not a valid Phone Number')
  } else {
    setSuccessMsg(phone)
  }

  //(((((((({{{{{{{ //validate password}}}}}}}))))))))
  if (passwordVal === '') {
    setErrorMsg(password, 'password cannot be blank')
  } else if (passwordVal.length <= 5) {
    setErrorMsg(password, 'password shoult atleast 6 character')
  } else {
    setSuccessMsg(password)
  }
  if (cpasswordVal === '') {
    setErrorMsg(cpassword, 'password cannot be blank')
  } else if (cpasswordVal != passwordVal) {
    setErrorMsg(cpassword, 'confirm password is match')
  } else {
    setSuccessMsg(cpassword)
  }
}





//set errorMsg function


function setErrorMsg(input, errormsgs) {
  const formControl = input.parentElement;        // for find parent div
  const small = formControl.querySelector('small')
  formControl.className = 'from-control error'   // for add error class in form-control

  small.innerText = errormsgs
}

function setSuccessMsg(input) {
  const formControl = input.parentElement;        // for find parent div

  formControl.className = 'from-control success'   // for add error class in form-control


}